package clase_1_java;

import java.security.DrbgParameters.NextBytes;
import java.util.Scanner;

public class main {

	public static void main(String[] args) {				
		// TODO Auto-generated method stub
		//realizar un programa que sume dos numeros//
		
		int a, b, c;
		
		Scanner teclado = new Scanner(System.in);
		
		System.out.println("ingresa el primer digito");
		a = teclado.nextInt();
		System.out.println("ingresa el segundo numero");
		b = teclado.nextInt();
		
		c = a + b;
		System.out.println("el resultado es:" +c);
		
		

	}

}
