package programa_que_resta_dos_numeros;

import java.util.Scanner;

public class main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		double interrogante ;
		int op = 0;
		
		Scanner teclado = new Scanner(System.in);
		
        System.out.println("ingresa una opcion");
        System.out.println("la primera suma dos digitos");
        System.out.println("la segunad resta dos digitos");
        System.out.println("la tercera divide dos digitos");
        System.out.println("la cuarta multiplica dos digitos");
        op = teclado.nextInt();
     
       
        
       switch(op)
    		   
       {
   	case 1: 
		
		int a, b, c;
		
		Scanner mirar = new Scanner(System.in);
		
		System.out.println("ingresa el primer digito");
		a = mirar.nextInt();
		System.out.println("ingresa el segundo numero");
		b = mirar.nextInt();
		
		c = a + b;
		System.out.println("el resultado es:" +c);
		break;
		
		
		case 2:
			int o, p, q;
			
			Scanner lo = new Scanner(System.in);
			
			System.out.println("ingresa el primer digito");
			o = lo.nextInt();
			System.out.println("ingresa el segundo numero");
			p = lo.nextInt();
			
			q = o - p;
			System.out.println("el resultado es:" +q);
			break;
			
		case 3:
			
			int v, s, h;
			
			Scanner leer = new Scanner(System.in);
			
			System.out.println("ingresa el primer digito");
			v= leer.nextInt();
			System.out.println("ingresa el segundo numero");
			s= leer.nextInt();
			
		
			
			if( s == 0)
			{
				System.out.println("no se puede dividir entre 0");
			}
			else
			{h=v /s;
			System.out.println("el resultado es:" +h);
			}
			
			break;
			
		case 4:
			int m, n, ñ;
			
			Scanner enter = new Scanner(System.in);
			
			System.out.println("ingresa el primer digito");
			m = enter.nextInt();
			System.out.println("ingresa el segundo numero");
			n = enter.nextInt();
			
			ñ = m *n;
			System.out.println("el resultado es:" +ñ);
			break;
		
		
		
		
		

	default:
		break;
	}
        
        
     
			
			
	
		}

	}


